# Sistema de Gestión de Ventas e Inventario — AutoPartes El Alto

Proyecto de grado de la carrera de Ingeniería de Sistemas, Universidad Privada
"Franz Tamayo". Sistema web para el control de ventas, inventario y compras de
una tienda de mecánica automotriz y repuestos en El Alto, La Paz - Bolivia.

## Descripción

El sistema resuelve los problemas del control manual (Excel/cuadernos) de una
tienda de repuestos: quiebres de stock, errores en ventas, falta de reportes y
pérdidas económicas. Permite registrar productos, ventas, compras, alertas de
stock mínimo, reportes de rotación y facturación básica.

## Objetivo general

Desarrollar un sistema para la tienda AutoPartes El Alto que controle el stock,
las ventas, compras y consultas del negocio.

## Tecnologías

- Backend: Python (Django) o Laravel
- Base de datos: MySQL
- Frontend: interfaz web responsive

## Estructura del repositorio

```
├── docs/     # Documento del proyecto de grado (PDF)
├── src/      # Código fuente del sistema
└── README.md
```

## Autor

- **Postulante:** Andre Ivan Rojas Valeriano
- **Tutor:** M.Sc. Marisol Arguedas Balladares

## Control de versiones

Este repositorio utiliza Git para el control de versiones del proyecto:

- `main`: rama estable del proyecto.
- `documentacion`: rama de trabajo para actualizar y organizar la documentación.

## Alcance del proyecto

- Registro y control de productos/repuestos.
- Gestión de ventas y compras.
- Alertas automáticas de stock mínimo.
- Reportes de rotación de inventario.
- Facturación básica.
